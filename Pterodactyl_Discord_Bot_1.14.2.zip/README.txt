You must have the NPM "request" in order for any requests to the Pterodactyl Panel to work.

"Pterodactyl Discord Bot" uses discord.js v12 and is recommended to use.
This requires node.js v12. Use "npm i discord.js@12.1.1" if you use the recommended version.

"Downgraded Pterodactyl Discord Bot" uses discord.js v11.
Use "npm i discord.js@11.6.4" if you use the downgraded version.
The downgraded version of the Pterodactyl Discord bot may be removed any time soon.
The downgraded version does the exact same processes as the original one, but uses "RichEmbed" instead of "MessageEmbed".